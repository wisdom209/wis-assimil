/* ==========================================================================
   Boucle — Bimodal Story Loop
   Vanilla JS. No build step. Everything lives in this one file:
     - data loading (lessons.json + audioUrls.json)
     - lesson index / lesson view / audio player
     - browser Speech Synthesis (shadowing)
     - a localStorage-backed SRS deck with an SM-2-flavoured scheduler
   ========================================================================== */

(() => {
  "use strict";

  /* ------------------------------------------------------------------ *
   *  Constants & state
   * ------------------------------------------------------------------ */

  const SRS_KEY = "boucle_srs_deck_v1";
  const AGAIN_DELAY_MS = 10 * 60 * 1000;       // "Again" resurfaces in 10 minutes
  const DAY_MS = 24 * 60 * 60 * 1000;

  const state = {
    lessons: [],          // array from lessons.json
    audioUrls: {},         // { "1": "https://..." }
    currentLessonId: null,
    view: "lesson",        // "lesson" | "review"
    speed: 1,
    frenchVoice: null,
    reviewQueue: [],        // snapshot of due cards for this session
    reviewIndex: 0,
    reviewAnswerShown: false,
  };

  /* ------------------------------------------------------------------ *
   *  DOM refs
   * ------------------------------------------------------------------ */

  const el = (id) => document.getElementById(id);

  const dom = {
    menuToggle: el("menuToggle"),
    sidebar: el("sidebar"),
    scrim: el("scrim"),
    lessonSearch: el("lessonSearch"),
    lessonIndex: el("lessonIndex"),
    viewTabs: document.querySelectorAll(".view-tab"),
    duePill: el("duePill"),

    lessonView: el("lessonView"),
    lessonEmpty: el("lessonEmpty"),
    lessonArticle: el("lessonArticle"),
    lessonEyebrow: el("lessonEyebrow"),
    lessonTitle: el("lessonTitle"),
    dialogue: el("dialogue"),
    newWordsSection: el("newWordsSection"),
    newWordsList: el("newWordsList"),

    audioEl: el("audioEl"),
    playPause: el("playPause"),
    scrubber: el("scrubber"),
    timeCurrent: el("timeCurrent"),
    timeTotal: el("timeTotal"),
    speedBtns: document.querySelectorAll(".speed-btn"),
    playerStatus: el("playerStatus"),

    reviewView: el("reviewView"),
    reviewEmpty: el("reviewEmpty"),
    reviewEmptyCount: el("reviewEmptyCount"),
    reviewNoDeck: el("reviewNoDeck"),
    reviewSession: el("reviewSession"),
    reviewCount: el("reviewCount"),
    reviewBarFill: el("reviewBarFill"),
    srsSource: el("srsSource"),
    srsPrompt: el("srsPrompt"),
    srsAnswer: el("srsAnswer"),
    srsFrench: el("srsFrench"),
    srsPron: el("srsPron"),
    srsPlayTts: el("srsPlayTts"),
    showAnswerBtn: el("showAnswerBtn"),
    gradeRow: el("gradeRow"),

    toast: el("toast"),
  };

  /* ------------------------------------------------------------------ *
   *  Utilities
   * ------------------------------------------------------------------ */

  function formatTime(seconds) {
    if (!isFinite(seconds) || seconds < 0) seconds = 0;
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return `${m}:${String(s).padStart(2, "0")}`;
  }

  let toastTimer = null;
  function showToast(message) {
    dom.toast.textContent = message;
    dom.toast.classList.add("is-visible");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => dom.toast.classList.remove("is-visible"), 1800);
  }

  function escapeHtml(str) {
    return String(str ?? "").replace(/[&<>"']/g, (c) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
    }[c]));
  }

  /* ------------------------------------------------------------------ *
   *  Data loading
   * ------------------------------------------------------------------ */

  async function loadData() {
    const [lessonsRes, audioRes] = await Promise.all([
      fetch("data/lessons.json"),
      fetch("data/audioUrls.json"),
    ]);
    if (!lessonsRes.ok) throw new Error(`Could not load data/lessons.json (${lessonsRes.status})`);
    if (!audioRes.ok) throw new Error(`Could not load data/audioUrls.json (${audioRes.status})`);

    state.lessons = await lessonsRes.json();
    state.audioUrls = await audioRes.json();
    state.lessons.sort((a, b) => a.id - b.id);
  }

  /* ------------------------------------------------------------------ *
   *  SRS deck — storage
   * ------------------------------------------------------------------ */

  function loadDeck() {
    try {
      const raw = localStorage.getItem(SRS_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (err) {
      console.error("Boucle: could not read SRS deck from localStorage", err);
      return [];
    }
  }

  function saveDeck(deck) {
    try {
      localStorage.setItem(SRS_KEY, JSON.stringify(deck));
    } catch (err) {
      console.error("Boucle: could not save SRS deck to localStorage", err);
      showToast("Couldn't save — storage may be full.");
    }
  }

  function makeCardId(lessonId, french) {
    return `${lessonId}::${french.trim().toLowerCase()}`;
  }

  function addToDeck({ lessonId, lessonTitle, french, english, pronunciation }) {
    if (!french || !french.trim()) return { ok: false, reason: "empty" };
    const deck = loadDeck();
    const id = makeCardId(lessonId, french);
    if (deck.some((c) => c.id === id)) {
      return { ok: false, reason: "duplicate" };
    }
    const now = Date.now();
    deck.push({
      id,
      lessonId,
      lessonTitle,
      french: french.trim(),
      english: (english || "").trim(),
      pronunciation: (pronunciation || "").trim(),
      ease: 2.5,
      interval: 0,
      reps: 0,
      dueAt: now,
      createdAt: now,
      lastReviewed: null,
    });
    saveDeck(deck);
    return { ok: true };
  }

  function dueCount(deck = loadDeck()) {
    const now = Date.now();
    return deck.filter((c) => c.dueAt <= now).length;
  }

  function refreshDuePill() {
    const n = dueCount();
    dom.duePill.hidden = n === 0;
    dom.duePill.textContent = n > 99 ? "99+" : String(n);
  }

  /* ------------------------------------------------------------------ *
   *  SRS deck — scheduler (SM-2 flavoured Leitner hybrid)
   * ------------------------------------------------------------------ */

  function scheduleCard(card, grade) {
    const now = Date.now();
    switch (grade) {
      case "again":
        card.reps = 0;
        card.interval = 0;
        card.ease = Math.max(1.3, card.ease - 0.2);
        card.dueAt = now + AGAIN_DELAY_MS;
        break;
      case "hard":
        card.ease = Math.max(1.3, card.ease - 0.15);
        card.interval = card.interval > 0 ? Math.max(1, Math.round(card.interval * 1.2)) : 1;
        card.reps += 1;
        card.dueAt = now + card.interval * DAY_MS;
        break;
      case "good":
        if (card.reps === 0) card.interval = 1;
        else if (card.reps === 1) card.interval = 3;
        else card.interval = Math.max(1, Math.round(card.interval * card.ease));
        card.reps += 1;
        card.dueAt = now + card.interval * DAY_MS;
        break;
      case "easy":
        card.interval = card.interval > 0 ? Math.round(card.interval * card.ease * 1.3) + 1 : 4;
        card.ease = card.ease + 0.15;
        card.reps += 1;
        card.dueAt = now + card.interval * DAY_MS;
        break;
      default:
        throw new Error(`Unknown grade: ${grade}`);
    }
    card.lastReviewed = now;
    return card;
  }

  function gradeCard(cardId, grade) {
    const deck = loadDeck();
    const idx = deck.findIndex((c) => c.id === cardId);
    if (idx === -1) return;
    scheduleCard(deck[idx], grade);
    saveDeck(deck);
    refreshDuePill();
  }

  /* ------------------------------------------------------------------ *
   *  Text-to-speech (shadowing)
   * ------------------------------------------------------------------ */

  function refreshVoices() {
    if (!("speechSynthesis" in window)) return;
    const voices = window.speechSynthesis.getVoices();
    state.frenchVoice =
      voices.find((v) => v.lang === "fr-FR") ||
      voices.find((v) => v.lang && v.lang.toLowerCase().startsWith("fr")) ||
      null;
  }

  if ("speechSynthesis" in window) {
    refreshVoices();
    window.speechSynthesis.onvoiceschanged = refreshVoices;
  }

  /**
   * Speak `text` in French, optionally repeating `loops` times.
   * `onStart`/`onEnd` toggle a "speaking" UI state on the triggering button.
   */
  function speakFrench(text, { loops = 1, onStart, onEnd } = {}) {
    if (!("speechSynthesis" in window)) {
      showToast("Speech synthesis isn't supported in this browser.");
      return;
    }
    window.speechSynthesis.cancel(); // clear any queued/stuck utterances first

    let remaining = Math.max(1, loops);
    onStart && onStart();

    const speakOnce = () => {
      const utter = new SpeechSynthesisUtterance(text);
      utter.lang = "fr-FR";
      if (state.frenchVoice) utter.voice = state.frenchVoice;
      utter.rate = 0.95;

      utter.onend = () => {
        remaining -= 1;
        if (remaining > 0) {
          setTimeout(speakOnce, 350);
        } else {
          onEnd && onEnd();
        }
      };
      utter.onerror = () => {
        onEnd && onEnd();
      };
      window.speechSynthesis.speak(utter);
    };

    speakOnce();
  }

  /* ------------------------------------------------------------------ *
   *  Audio player (lesson recordings)
   * ------------------------------------------------------------------ */

  function resetPlayerUI() {
    dom.scrubber.value = 0;
    dom.timeCurrent.textContent = "0:00";
    dom.timeTotal.textContent = "0:00";
    setPlayingIcon(false);
    dom.playerStatus.hidden = true;
  }

  function setPlayingIcon(isPlaying) {
    dom.playPause.querySelector(".icon-play").hidden = isPlaying;
    dom.playPause.querySelector(".icon-pause").hidden = !isPlaying;
    dom.playPause.setAttribute("aria-label", isPlaying ? "Pause audio" : "Play audio");
  }

  function loadLessonAudio(lessonId) {
    const url = state.audioUrls[String(lessonId)];
    resetPlayerUI();
    if (!url) {
      dom.playerStatus.hidden = false;
      dom.playerStatus.textContent = "No audio found for this lesson.";
      dom.audioEl.removeAttribute("src");
      dom.playPause.disabled = true;
      dom.scrubber.disabled = true;
      return;
    }
    dom.playPause.disabled = false;
    dom.scrubber.disabled = false;
    dom.audioEl.src = url;
    dom.audioEl.playbackRate = state.speed;
    dom.audioEl.load();
  }

  dom.playPause.addEventListener("click", () => {
    if (!dom.audioEl.src) return;
    if (dom.audioEl.paused) {
      const p = dom.audioEl.play();
      if (p && p.catch) {
        p.catch(() => {
          dom.playerStatus.hidden = false;
          dom.playerStatus.textContent = "Couldn't play this file — check the audio URL.";
        });
      }
    } else {
      dom.audioEl.pause();
    }
  });

  dom.audioEl.addEventListener("play", () => setPlayingIcon(true));
  dom.audioEl.addEventListener("pause", () => setPlayingIcon(false));
  dom.audioEl.addEventListener("ended", () => setPlayingIcon(false));

  dom.audioEl.addEventListener("loadedmetadata", () => {
    dom.scrubber.max = dom.audioEl.duration || 0;
    dom.timeTotal.textContent = formatTime(dom.audioEl.duration);
  });

  dom.audioEl.addEventListener("timeupdate", () => {
    dom.scrubber.value = dom.audioEl.currentTime;
    dom.timeCurrent.textContent = formatTime(dom.audioEl.currentTime);
  });

  dom.audioEl.addEventListener("error", () => {
    if (!dom.audioEl.src) return;
    dom.playerStatus.hidden = false;
    dom.playerStatus.textContent = "This lesson's audio couldn't be loaded.";
  });

  dom.scrubber.addEventListener("input", () => {
    dom.audioEl.currentTime = Number(dom.scrubber.value);
  });

  dom.speedBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      state.speed = Number(btn.dataset.speed);
      dom.audioEl.playbackRate = state.speed;
      dom.speedBtns.forEach((b) => b.classList.toggle("is-active", b === btn));
    });
  });

  /* ------------------------------------------------------------------ *
   *  Rendering — sidebar (lesson index)
   * ------------------------------------------------------------------ */

  function renderSidebar(filterText = "") {
    const q = filterText.trim().toLowerCase();
    dom.lessonIndex.innerHTML = "";

    const frag = document.createDocumentFragment();
    state.lessons.forEach((lesson) => {
      const hay = `${lesson.id} ${lesson.title}`.toLowerCase();
      if (q && !hay.includes(q)) return;

      const li = document.createElement("li");
      const btn = document.createElement("button");
      btn.className = "lesson-btn" + (lesson.id === state.currentLessonId ? " is-active" : "");
      btn.dataset.lessonId = lesson.id;

      const isRevision = lesson.type === "revision";
      btn.innerHTML = `
        <span class="lesson-num">${lesson.id}</span>
        <span class="lesson-name">${escapeHtml(lesson.title)}</span>
        ${isRevision ? '<span class="lesson-tag">Révision</span>' : ""}
      `;
      btn.addEventListener("click", () => selectLesson(lesson.id));
      li.appendChild(btn);
      frag.appendChild(li);
    });
    dom.lessonIndex.appendChild(frag);
  }

  dom.lessonSearch.addEventListener("input", () => renderSidebar(dom.lessonSearch.value));

  /* ------------------------------------------------------------------ *
   *  Rendering — lesson view
   * ------------------------------------------------------------------ */

  function renderLesson(lesson) {
    dom.lessonEmpty.hidden = true;
    dom.lessonArticle.hidden = false;

    dom.lessonEyebrow.textContent =
      `Lesson ${lesson.id}${lesson.type === "revision" ? " · Révision" : ""}`;
    dom.lessonTitle.textContent = lesson.title;

    loadLessonAudio(lesson.id);
    renderDialogue(lesson);
    renderNewWords(lesson);
  }

  function renderDialogue(lesson) {
    const deck = loadDeck();
    dom.dialogue.innerHTML = "";
    const frag = document.createDocumentFragment();

    (lesson.dialogue || []).forEach((line, idx) => {
      const cardId = makeCardId(lesson.id, line.french || "");
      const isSaved = deck.some((c) => c.id === cardId);

      const row = document.createElement("div");
      row.className = "line";
      row.innerHTML = `
        <span class="line-speaker">${escapeHtml(line.speaker ?? idx + 1)}</span>
        <div class="line-text">
          <p class="line-french">${escapeHtml(line.french)}</p>
          <p class="line-english">${escapeHtml(line.english)}</p>
        </div>
        <div class="line-actions">
          <button class="chip-btn tts-line-btn" type="button" data-french="${escapeHtml(line.french)}">🔊 Play</button>
          <label class="loop-toggle">
            <input type="checkbox" class="loop-check"> Loop 3×
          </label>
          <button class="chip-btn srs-add-btn ${isSaved ? "is-saved" : ""}" type="button"
            data-french="${escapeHtml(line.french)}"
            data-english="${escapeHtml(line.english)}"
            data-pron="${escapeHtml(line.pronunciation || "")}">
            ${isSaved ? "✓ In deck" : "➕ Add to SRS"}
          </button>
        </div>
      `;
      frag.appendChild(row);
    });

    dom.dialogue.appendChild(frag);
  }

  function renderNewWords(lesson) {
    const words = lesson.new_words || [];
    if (!words.length) {
      dom.newWordsSection.hidden = true;
      return;
    }
    dom.newWordsSection.hidden = false;
    const deck = loadDeck();
    dom.newWordsList.innerHTML = "";
    const frag = document.createDocumentFragment();

    words.forEach((w) => {
      const cardId = makeCardId(lesson.id, w.french || "");
      const isSaved = deck.some((c) => c.id === cardId);
      const li = document.createElement("li");
      li.className = "word-item";
      li.innerHTML = `
        <span class="word-fr">${escapeHtml(w.french)}</span>
        <span class="word-en">${escapeHtml(w.english)}</span>
        <button class="chip-btn srs-add-btn ${isSaved ? "is-saved" : ""}" type="button"
          data-french="${escapeHtml(w.french)}"
          data-english="${escapeHtml(w.english)}"
          data-pron="">
          ${isSaved ? "✓" : "➕"}
        </button>
      `;
      frag.appendChild(li);
    });
    dom.newWordsList.appendChild(frag);
  }

  // Event delegation for TTS + Add-to-SRS buttons inside the lesson article
  dom.lessonArticle.addEventListener("click", (e) => {
    const ttsBtn = e.target.closest(".tts-line-btn");
    if (ttsBtn) {
      const french = ttsBtn.dataset.french;
      const row = ttsBtn.closest(".line-actions");
      const loopChecked = row.querySelector(".loop-check")?.checked;
      const loops = loopChecked ? 3 : 1;
      speakFrench(french, {
        loops,
        onStart: () => ttsBtn.classList.add("is-speaking"),
        onEnd: () => ttsBtn.classList.remove("is-speaking"),
      });
      return;
    }

    const addBtn = e.target.closest(".srs-add-btn");
    if (addBtn) {
      if (addBtn.classList.contains("is-saved")) {
        showToast("Already in your deck.");
        return;
      }
      const lesson = state.lessons.find((l) => l.id === state.currentLessonId);
      const result = addToDeck({
        lessonId: lesson.id,
        lessonTitle: lesson.title,
        french: addBtn.dataset.french,
        english: addBtn.dataset.english,
        pronunciation: addBtn.dataset.pron,
      });
      if (result.ok) {
        addBtn.classList.add("is-saved");
        addBtn.textContent = addBtn.closest(".word-item") ? "✓" : "✓ In deck";
        showToast("Added to your SRS deck.");
        refreshDuePill();
      } else if (result.reason === "duplicate") {
        addBtn.classList.add("is-saved");
        showToast("Already in your deck.");
      }
      return;
    }
  });

  /* ------------------------------------------------------------------ *
   *  Lesson selection
   * ------------------------------------------------------------------ */

  function selectLesson(id) {
    const lesson = state.lessons.find((l) => l.id === Number(id));
    if (!lesson) return;
    state.currentLessonId = lesson.id;
    renderLesson(lesson);
    renderSidebar(dom.lessonSearch.value); // refresh active state
    closeSidebarOnMobile();
    dom.lessonView.scrollTo({ top: 0, behavior: "instant" in window ? "instant" : "auto" });
  }

  /* ------------------------------------------------------------------ *
   *  Mobile sidebar drawer
   * ------------------------------------------------------------------ */

  function openSidebar() {
    dom.sidebar.classList.add("is-open");
    dom.scrim.classList.add("is-open");
    dom.menuToggle.setAttribute("aria-expanded", "true");
  }
  function closeSidebar() {
    dom.sidebar.classList.remove("is-open");
    dom.scrim.classList.remove("is-open");
    dom.menuToggle.setAttribute("aria-expanded", "false");
  }
  function closeSidebarOnMobile() {
    if (window.matchMedia("(max-width: 900px)").matches) closeSidebar();
  }
  dom.menuToggle.addEventListener("click", () => {
    dom.sidebar.classList.contains("is-open") ? closeSidebar() : openSidebar();
  });
  dom.scrim.addEventListener("click", closeSidebar);

  /* ------------------------------------------------------------------ *
   *  View switching (Lessons / Review)
   * ------------------------------------------------------------------ */

  function setView(view) {
    state.view = view;
    dom.lessonView.hidden = view !== "lesson";
    dom.reviewView.hidden = view !== "review";
    dom.viewTabs.forEach((tab) => {
      const active = tab.dataset.view === view;
      tab.classList.toggle("is-active", active);
      tab.setAttribute("aria-selected", String(active));
    });
    if (view === "review") startReviewSession();
  }

  dom.viewTabs.forEach((tab) => tab.addEventListener("click", () => setView(tab.dataset.view)));

  /* ------------------------------------------------------------------ *
   *  Review (SRS) session
   * ------------------------------------------------------------------ */

  function startReviewSession() {
    window.speechSynthesis && window.speechSynthesis.cancel();
    const deck = loadDeck();
    const now = Date.now();
    const due = deck.filter((c) => c.dueAt <= now).sort((a, b) => a.dueAt - b.dueAt);

    if (deck.length === 0) {
      dom.reviewNoDeck.hidden = false;
      dom.reviewEmpty.hidden = true;
      dom.reviewSession.hidden = true;
      return;
    }
    if (due.length === 0) {
      dom.reviewNoDeck.hidden = true;
      dom.reviewEmpty.hidden = false;
      dom.reviewSession.hidden = true;
      dom.reviewEmptyCount.textContent = deck.length;
      return;
    }

    state.reviewQueue = due;
    state.reviewIndex = 0;
    dom.reviewNoDeck.hidden = true;
    dom.reviewEmpty.hidden = true;
    dom.reviewSession.hidden = false;
    showReviewCard();
  }

  function showReviewCard() {
    const card = state.reviewQueue[state.reviewIndex];
    if (!card) {
      startReviewSession(); // re-check: session finished
      return;
    }
    state.reviewAnswerShown = false;

    dom.reviewCount.textContent =
      `Card ${state.reviewIndex + 1} of ${state.reviewQueue.length}`;
    dom.reviewBarFill.style.width =
      `${Math.round((state.reviewIndex / state.reviewQueue.length) * 100)}%`;

    dom.srsSource.textContent = `Lesson ${card.lessonId} · ${card.lessonTitle}`;
    dom.srsPrompt.textContent = card.english || "(no translation saved)";
    dom.srsFrench.textContent = card.french;
    dom.srsPron.textContent = card.pronunciation || "";
    dom.srsPron.hidden = !card.pronunciation;

    dom.srsAnswer.hidden = true;
    dom.showAnswerBtn.hidden = false;
    dom.gradeRow.hidden = true;
  }

  dom.showAnswerBtn.addEventListener("click", () => {
    dom.srsAnswer.hidden = false;
    dom.showAnswerBtn.hidden = true;
    dom.gradeRow.hidden = false;
    state.reviewAnswerShown = true;
  });

  dom.srsPlayTts.addEventListener("click", () => {
    const card = state.reviewQueue[state.reviewIndex];
    if (!card) return;
    speakFrench(card.french, {
      onStart: () => dom.srsPlayTts.classList.add("is-speaking"),
      onEnd: () => dom.srsPlayTts.classList.remove("is-speaking"),
    });
  });

  dom.gradeRow.addEventListener("click", (e) => {
    const btn = e.target.closest(".grade-btn");
    if (!btn) return;
    const card = state.reviewQueue[state.reviewIndex];
    if (!card) return;
    gradeCard(card.id, btn.dataset.grade);
    state.reviewIndex += 1;
    if (state.reviewIndex >= state.reviewQueue.length) {
      dom.reviewBarFill.style.width = "100%";
      // brief pause so the bar can visually complete, then re-check due cards
      setTimeout(startReviewSession, 200);
    } else {
      showReviewCard();
    }
  });

  /* ------------------------------------------------------------------ *
   *  Init
   * ------------------------------------------------------------------ */

  async function init() {
    try {
      await loadData();
    } catch (err) {
      console.error(err);
      dom.lessonEmpty.innerHTML = `
        <p><strong>Couldn't load lesson data.</strong></p>
        <p style="font-family: var(--sans); font-size: 0.9rem;">
          Make sure <code>data/lessons.json</code> and <code>data/audioUrls.json</code>
          are present next to <code>index.html</code>.<br>
          (${escapeHtml(err.message)})
        </p>`;
      return;
    }

    renderSidebar();
    refreshDuePill();

    if (state.lessons.length) {
      selectLesson(state.lessons[0].id);
    }
  }

  init();
})();
